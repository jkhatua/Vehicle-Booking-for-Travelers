<?php
include('config.php');
if(!empty($_POST['id'])){
  $id = $_POST['id'];
  function deleteSupplier($id){
    global $mysqli;
    $stmt = $mysqli->prepare("DELETE
    FROM sellitems
    WHERE id = ?
    ");
    $stmt->bind_param("s",$id);
    $stmt->execute();
  }

  $sql = deleteSupplier($id);



} ?>
