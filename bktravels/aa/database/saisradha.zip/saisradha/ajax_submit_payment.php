<?php
//print_r($_POST);

include 'config.php';

$name = $_POST['name'];
$contact = $_POST['contact'];
$invoice_no = $_POST['invoice_no'];
$amount = $_POST['amount'];
$pending = $_POST['pending'];
$date = $_POST['date'];
$remarks = $_POST['remarks'];
$bill = $_POST['bill'];
$invAmount = $_POST['invAmount'];

$new_pending =  $amount - $pending;

//print_r($new_pending);

function updatePayment($name,$contact,$invoice_no,$amount,$pending,$date,$remarks,$bill,$new_pending,$invAmount){
  global $mysqli;
  $stmt = $mysqli->prepare("INSERT INTO transHistory(
    name,
    contact,
    invoice_no,
    amount,
    pending,
    date,
    remarks,
    bill,
    newBal,
    invAmount
  ) VALUES (
    ?,
    ?,
    ?,
    ?,
    ?,
    ?,
    ?,
    ?,
    ?,
    ?
  )");
  $stmt->bind_param("ssssssssss",$name,$contact,$invoice_no,$amount,$pending,$date,$remarks,$bill,$new_pending,$invAmount);
  $stmt->execute();
  $inserted_id = $mysqli->insert_id;
  $stmt->close();
  if($inserted_id > 0){
    return $inserted_id;
  } else {
    return "";
  }
}

function updateBill($new_pending,$bill){
  global $mysqli;
  $stmt = $mysqli->prepare("UPDATE insertProduct SET
  freight = ?
  WHERE bill = ?
  ");
  $stmt->bind_param("ss",$new_pending,$bill);
  $result = $stmt->execute();
  $stmt->close();
  return $result;
}

$sql = updatePayment($name,$contact,$invoice_no,$amount,$pending,$date,$remarks,$bill,$new_pending,$invAmount);
print_r($sql);

$sql1 = updateBill($new_pending,$bill);
print_r($sql1);

 ?>
