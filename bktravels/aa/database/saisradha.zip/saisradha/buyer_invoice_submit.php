<?php
	include('config.php');

		$customer_details = $_POST['customer_details'];
		$date = $_POST['start_date'];
		$order_no = $_POST['order_no'];
		$so_no = $_POST['so_no'];
		$invoice_no = $_POST['invoice_no'];
		$place_of_supply = $_POST['place_of_supply'];
		$serial_no = $_POST['sl_no'];
		$mat_code = $_POST['mat_code'];
		$mat_des = $_POST['mat_des'];
		$customer_drg_no = $_POST['customer_drg_no'];
		$quantity = $_POST['quantity'];
		//$item_value = $_POST['item_value'];
		$discount = $_POST['discount'];
		$amount = $_POST['amount'];
		$pay_cost = $_POST['pay_cost'];
		//$pl_serial_no = $_POST['pl_serial_no'];
		$freight = $_POST['freight'];
		$hsn_code = $_POST['hsn_code'];
		//if($order_no==0)  $order_no=0;
		$rate = $_POST['rate'];
		$cgst=$_POST['cgst'] ;
		$sgst = $_POST['sgst'];
		$igst = $_POST['igst'];
		$tax_cost = $_POST['tax_cost'];
		$quantity_avail = $_POST['quantity'];

function fetchLastBill(){
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT
	bill
	FROM insertProduct
	ORDER BY id DESC LIMIT 1
	");
	$stmt->execute();
	$stmt->bind_result($bill);
	$stmt->store_result();
  $stmt->fetch();
  $stmt->close();
	return $bill;
}


function insertProduct($customer_details,$order_no,$date,$so_no,$invoice_no,$place_of_supply,&$serial_no,&$mat_des,&$mat_code,&$hsn_code,$freight,&$cgst,&$sgst,&$igst,&$customer_drg_no,&$quantity,&$rate,&$discount,&$amount,&$tax_cost,$pay_cost,$bill_no,&$quantity_avail){
	global $mysqli;
	$stmt = $mysqli->prepare("INSERT INTO insertProduct(
		customer_details,
		order_no,
		rdate,
		so_no,
		invoice_no,
		place_of_supply,
		sl_no,
		mat_des,
		mat_code,
		hsn_code,
		freight,
		cgst,
		sgst,
		igst,
		customer_drg_no,
		quantity,
		rate,
		discount,
		amount,
		tax_cost,
		pay_cost,
		bill,
		quantity_avail
		)
		VALUES (
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?,
			?
		)");
		$stmt->bind_param("sssssssssssssssssssssss",$customer_details,$order_no,$date,$so_no,$invoice_no,$place_of_supply,$serial_no,$mat_des,$mat_code,$hsn_code,$freight,$cgst,$sgst,$igst,$customer_drg_no,$quantity,$rate,$discount,$amount,$tax_cost,$pay_cost,$bill_no,$quantity_avail);
		$stmt->execute();
		$inserted_id = $mysqli->insert_id;
		$stmt->close();
		if($inserted_id>0)
		{
			return $inserted_id;
		}
		else
		{
			return false;
		}
}

function stockDetails($invoice_no,&$mat_des,&$mat_code,&$hsn_code,&$quantity,$date,&$used){
	global $mysqli;
	$stmt = $mysqli->prepare("INSERT INTO stockDetails(
	invoice_no,
	mat_des,
	mat_code,
	hsn_code,
	quantity,
	rdate,
	avail
	)
	VALUES(
		?,
		?,
		?,
		?,
		?,
		?,
		?
	)");
	$stmt->bind_param("sssssss",$invoice_no,$mat_des,$mat_code,$hsn_code,$quantity,$date,$used);
	$stmt->execute();
	$inserted_id = $mysqli->insert_id;
	$stmt->close();
	if($inserted_id>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

$bill_no = fetchLastBill()+1;


if(!empty($pay_cost)){
	for($i = 0; $i<count($serial_no); $i++) {
		$sql = insertProduct($customer_details,$order_no,$date,$so_no,$invoice_no,$place_of_supply,$serial_no[$i],$mat_des[$i],$mat_code[$i],$hsn_code[$i],$freight,$cgst[$i],$sgst[$i],$igst[$i],$customer_drg_no[$i],
		$quantity[$i],$rate[$i],$discount[$i],$amount[$i],$tax_cost[$i],$pay_cost,$bill_no,$quantity_avail[$i]);
		print_r($sql);
	}
}
if(!empty($quantity)){
	for($j = 0; $j<count($quantity); $j++){
		$sql1 = stockDetails($invoice_no,$mat_des[$j],$mat_code[$j],$hsn_code[$j],$quantity[$j],$date,$used[$j]);
	}
}


 	?>
<!-- // 	<html>
