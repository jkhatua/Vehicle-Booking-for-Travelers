<?php
//error_reporting(0);
if(!empty($_GET['printid'])) {
?>
<style>
table {
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;

}
span{
  text-transform: uppercase;
}
p{
    margin-top: 2px;
    margin-bottom: 2px;
}
body{
  margin-left: 40px;
  margin-right: 40px;
}
hr{
  margin-top: 2px;
  margin-bottom: 2px;
}
@media print {
html,body{height:100%;width:100%;margin:0;padding:0;}
 @page {
  size: 21cm 29.7cm;
	max-height:100%;
	max-width:100%
  font-size: 8pt;
  overflow: hidden;
	}
}
  #printbtn{
    visibility: : none !important;
  }
</style>
<?php
include("config.php");
require_once("include/numbertowords.php");

function IsfetchExistingCustomer($id){
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT DISTINCT
	customer_details
	FROM sellItems
  WHERE bill = ?
	");
  $stmt->bind_param("s",$id);
	$stmt->execute();
	$stmt->bind_result($customer);
	$stmt->store_result();
  $stmt->fetch();
  $stmt->close();
	return $customer;
}

function IfCustomerNew($id){
    global $mysqli;
    $stmt = $mysqli->prepare("SELECT
    new_customer,
    address,
    gstin
    FROM sellItems
    WHERE bill = ?
    LIMIT 1
    ");
    $stmt->bind_param("s",$id);
    $stmt->execute();
    $stmt->bind_result($new_customer,$address,$gstin);
    while($stmt->fetch()){
      $row[] = array('new_customer' =>$new_customer ,'address'=>$address,'gstin'=>$gstin );
    }
    if(!empty($row))
    {
      return $row;
    }
    else
    {
      return "";
    }

}

function fetchBuyer($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  buyerDetails.name as customerName,
  buyerDetails.address as Address,
  buyerDetails.gstin,
  buyerDetails.pan,
  buyerDetails.cin
  FROM sellItems
  INNER JOIN buyerDetails ON sellItems.customer_details = buyerDetails.id
  WHERE sellItems.bill = ?
  LIMIT 1
  ");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($customerName,$address,$gstin,$pan,$cin);
  while($stmt->fetch()){
    $row[] = array('customerName' => $customerName,'address'=>$address,'gstin'=>$gstin,'pan'=>$pan,'cin'=>$pan );
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else{
    return "";
  }
}
$id = $_GET['printid'];

if(IsfetchExistingCustomer($id) == 0){
$customer =IfCustomerNew($id);
} else {
$customer = fetchBuyer($id); }
  foreach ($customer as $v1) {}

 ?>
<!DOCTYPE html>
<html lang="en">
<body>
<table width="100%">

  <tr>
    <td>
      <p style="font-size:20;text-align:center;">TAX INVOICE</p>
    </td>
  </tr>
</table>
<br>
<table width="100%">
  <tr>
    <td>
      <p>Billed To</p>
  	      <?php  if(IsfetchExistingCustomer($id) == 0){ echo $v1['new_customer']; } else {echo $v1['customerName'];}?>,</p>
          <?php echo $v1['address'];?>,</p>
          State &amp; State Code:ODISHA,21</p>
          GSTIN :<?php echo $v1['gstin'];?>
    </td>
    <td>
      	  <b>PADMALAYA</b></p>
		  AUTH. DEALER : FINOLEX CABLE, CG LIGHTING, ALMONARD FANS</p>
		  ANCHOR, CONA, LEGRAND, PHILIPS, BAJAJ, MARU</p>
          Shop No. 01-37/38, P.D. Market</p>
          CRP Square, BBSR-15</p>
          Ph. 0674-2560909 (O), 9437060909</p>
          GSTIN :21AATPC0841J1ZY
    </td>
    <?php
    function fetchProductDetails($id){
      global $mysqli;
      $stmt = $mysqli->prepare("SELECT
      po_no,
      date,
      dispatched,
      invoice_no,
      state,
      remarks
      FROM sellItems
      WHERE bill =?
      LIMIT 1
      ");
      $stmt->bind_param("s",$id);
      $stmt->execute();
      $stmt->bind_result($po_no,$date,$dispatched,$invoice_no,$state,$remarks);
      while($stmt->fetch()){
        $row[] = array('po_no' =>$po_no ,'date'=>$date,'dispatched'=>$dispatched,'invoice_no'=>$invoice_no,'state' =>$state,'remarks'=>$remarks);
      }
      $stmt->close();
      if(!empty($row)){
        return $row;
      } else{
        return "";
      }
    }
     ?>
     <?php $result = fetchProductDetails($id);
     foreach ($result as $v2) { ?>
    <td>
      <br>
      <p style="text-align:center;">ORIGINAL</p>
      <br>
      <hr>
      <p>Invoice No: <span><?php echo $v2['invoice_no'];?></span></p>
      <p>Date: <span><?php echo $v2['date'];?></span></p>
    </td>
  </tr>

  <?php } ?>
</table>
<br>
<table width="100%">
  <tr>
    <th>
      Sl. No.
    </th>
    <th>
     Description of goods
    </th>
	<th>Part No</th>
    <th>
      HSN/SAC Code
    </th>
    <th>
      Quantity
    </th>
    <th>
     Unit price
    </th>
    <th>
      Discount
    </th>
    <th>
      Total Value
    </th>
  </tr>
  <?php
  function fetchProductDetails1($id){
    global $mysqli;
    $stmt = $mysqli->prepare("SELECT
    sellItems.invoice_no,
    date,
    po_no,
    insertProduct.mat_des,
    sellItems.quantity,
    sellItems.rate,
    sellItems.discount,
    sellItems.amount,
    pl_serial_no,
	sellItems.hsn_code,
	insertproduct.mat_code,
	item_value
    FROM sellItems
    INNER JOIN insertProduct ON sellItems.mat_des = insertProduct.id
    WHERE sellItems.bill = ?
    ");
    $stmt->bind_param("s",$id);
    $stmt->execute();
    $stmt->bind_result($invoice_no,$date,$po_no,$mat_des,$quantity,$rate,$discount,$amount,$pl_serial_no,$hsn_code,$mat_code,$item_value);
    while($stmt->fetch()){
      $row[] = array('invoice_no' => $invoice_no,'date'=>$date,'po_no'=>$po_no,'mat_des'=>$mat_des,'quantity'=>$quantity,'rate'=>$rate,'discount'=>$discount,'amount'=>$amount,'pl_serial_no'=>$pl_serial_no,'hsn_code'=>$hsn_code,'mat_code'=>$mat_code,'item_value'=>$item_value );
    }
    $stmt->close();
    if(!empty($row)){
      return $row;
    } else{
      return "";
    }
  }
  $i=0;
   $result = fetchProductDetails1($id);
  foreach ($result as $v2) { ?>
  <tr>
    <td>
      <p style="text-align:center;">#<?php echo ++$i; ?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $v2['mat_des'];?></p>
    </td>
	 <td>
      <p style="text-align:center;"><?php echo $v2['mat_code'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $v2['hsn_code'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $v2['quantity'];?></p>
    </td>
    <td>
      <p style="text-align:center;">Rs&nbsp;<?php echo $v2['rate'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $v2['discount'];?>%</p>
    </td>
    <td>
      <p style="text-align:center;">Rs&nbsp;<?php echo round($v2['item_value'],2);?>/-</p>
    </td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="6">
    </td>
    <?php
    function fetchtaxes($id){
      global $mysqli;
      $stmt = $mysqli->prepare("SELECT
      SUM(amount),
      avg(cgst),
      avg(igst),
      avg(sgst),
      pay_cost,
      SUM(item_value)
      FROM sellItems
      WHERE bill = ?
      ");
      $stmt->bind_param("s",$id);
      $stmt->execute();
      $stmt->bind_result($amount,$cgst,$igst,$sgst,$pay_cost,$item_value);
      while($stmt->fetch()){
        $row[] = array('cgst'=>$cgst,'igst'=>$igst,'sgst'=>$sgst,'pay_cost'=>$pay_cost,'item_value'=>$item_value,'amount'=>$amount);
      }
      if(!empty($row))
    	{
    		return ($row);
    	}
    	else
    	{
    		return "";
    	}
    }
    $taxess = fetchtaxes($id);
    foreach ($taxess as $v5) {}


    ?>
    <td>
	
      <p style="text-align:center;">Total</p>
      <hr>

      <p style="text-align:center;">CGST</p>
      <hr>
      <p style="text-align:center;">SGST</p>
      <hr>
	  <p style="text-align:center;">IGST</p>
      <hr>
      <p style="text-align:center;">Grand Total Rs.</p>
    </td>
    <td>
		
      <p style="text-align:center;"><?php  echo round(($v5['item_value']),2);  ?></p>

        <hr>

        <p style="text-align:center;"><?php echo round(($v5['cgst'])/100 * ($v5['item_value']),2); ?></p>
        <hr>
        <p style="text-align:center;"><?php echo round(($v5['cgst'])/100 * ($v5['item_value']),2); ?></p>
        <hr>
        <p style="text-align:center;"><?php echo ($v5['igst'])/100 * ($v5['item_value']); ?></p>
        <hr>
        <p style="text-align:center;">&nbsp; <?php echo (int)$v5['pay_cost']; ?>.00</p>
    </td>
  </tr>
</table>
<?php  $tax = (($v5['cgst'])/100 * ($v5['item_value'])) + (($v5['sgst'])/100 * ($v5['item_value'])) + (($v5['igst'])/100 * ($v5['item_value'])) ;  ?>
<p>Total GST In Word Rupees:<?php $new_igst=convert_number_to_words($tax);
		 echo  strtoupper($new_igst);?> ONLY</p>
<p>Total Invoice Value In Words Rupees:<?php $new_s_total=convert_number_to_words($v5['pay_cost']);
		 echo  strtoupper($new_s_total);?> ONLY </p>
     <table width="100%">
       <tr>
         <td>
             <p>1. Goods once sold will not be returned.</p>
             <p>2. All disputes are subject to Bhubaneswar Juridiction only.</p>
			 <p>Bank Name: Andra Bank, Baramunda.</p>
			 <p>Bank Account No.: 018813046000701</p>
			 <p>Branch IFSC : ANDB0000188</p>
         </td>
         <td>
          <p style="text-align:center;">for PADMALAYA</p>
           <br>
           <br>
           <p style="text-align:center;">Proprietor</p>
         </td>
       </tr>

     </table>
     <br>

     <br>
     <br>
     <br>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$( document ).ready(function() {

 // window.print();
//  window.close();
});
</script>
</html>

<?php } else {header('Location : dashboard.php');}  ?>
