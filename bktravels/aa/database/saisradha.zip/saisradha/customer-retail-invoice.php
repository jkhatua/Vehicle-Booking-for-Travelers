
<style>
table {
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;

}
span{
  text-transform: uppercase;
}
p{
    margin-top: 2px;
    margin-bottom: 2px;
}
body{
  margin-left: 40px;
  margin-right: 40px;
}
hr{
  margin-top: 2px;
  margin-bottom: 2px;
}
@media print {
html,body{height:100%;width:100%;margin:0;padding:0;}
 @page {
  size: 21cm 29.7cm;
	max-height:100%;
	max-width:100%
  font-size: 8pt;
  overflow: hidden;
	}
}
  #printbtn{
    visibility: : none !important;
  }
</style>
<?php
include("config.php");
require_once("include/numbertowords.php");

$customer_details = $_POST['new_customer'];
$date = $_POST['date'];
$date = date("y-m-h",strtotime($date));
$address = $_POST['address'];
//$order_no = $_POST['order_no'];
//$so_no = $_POST['so_no'];
$invoice_no = $_POST['invoice_no'];
//$place_of_supply = $_POST['place_of_supply'];
$serial_no = $_POST['serial_no'];
//$mat_code = $_POST['mat_code'];
$mat_des = $_POST['mat_des'];
//$customer_drg_no = $_POST['customer_drg_no'];
$quantity = $_POST['quantity'];
$gstin = $_POST['gstin'];
$item_value = $_POST['item_value'];
$discount = $_POST['discount'];
$amount = $_POST['amount'];
$pay_cost = $_POST['pay_cost'];
$pl_serial_no = $_POST['pl_serial_no'];
//$freight = $_POST['freight'];
$hsn_code = $_POST['hsn_code'];
//if($order_no==0)  $order_no=0;
$rate = $_POST['rate'];
$cgst=$_POST['cgst'] ;
$sgst = $_POST['sgst'];
$igst = $_POST['igst'];
//$tax_cost = $_POST['tax_cost'];
$quantity_avail = $_POST['quantity'];
$total_cost = $_POST['total_cost1'];

 ?>
<!DOCTYPE html>
<html lang="en">
<body>
<table width="100%">

  <tr>
    <td>
      <p style="font-size:20;text-align:center;">TAX INVOICE</p>
    </td>
  </tr>
</table>
<br>
<table width="100%">
  <tr>
    <td>
      <p>Billed To</p>
  	      <?php  echo $customer_details?>,</p>
          <?php echo $address;?>,</p>
          State &amp; State Code:ODISHA,21</p>
          GSTIN :<?php echo $gstin;?>
    </td>
    <td>
      	  <b>PADMALAYA</b></p>
		  AUTH. DEALER : FINOLEX CABLE, CG LIGHTING, ALMONARD FANS</p>
		  ANCHOR, CONA, LEGRAND, PHILIPS, BAJAJ, MARU</p>
          Shop No. 01-37/38, P.D. Market</p>
          CRP Square, BBSR-15</p>
          Ph. 0674-2560909 (O), 9437060909</p>
          GSTIN :21AATPC0841J1ZY
    </td>

    <td>
      <br>
      <p style="text-align:center;">ORIGINAL</p>
      <br>
      <hr>
      <p>Invoice No: <span><?php echo $invoice_no?></span></p>
      <p>Date: <span><?php echo $date;?></span></p>
    </td>
  </tr>

</table>
<br>
<table width="100%">
  <tr>
    <th>
      Sl. No.
    </th>
    <th>
     Description in cases of goods/Service
    </th>
    <th>
      HSN/SAC Code of the Good
    </th>
    <th>
      Quantity
    </th>
    <th>
     Unit price
    </th>
    <th>
      Discount
    </th>
    <th>
      Total Value
    </th>
  </tr>
  <?php
  for($i=0;$i<count($serial_no);$i++) {
      $rows[$i]['sl_no'] = $serial_no[$i];
      $rows[$i]['mat_des'] = $mat_des[$i];
      $rows[$i]['hsn_code'] = $hsn_code[$i];
      $rows[$i]['cgst'] = $cgst[$i];
      $rows[$i]['sgst'] = $sgst[$i];
      $rows[$i]['igst'] = $igst[$i];
      $rows[$i]['quantity'] = $quantity[$i];
      $rows[$i]['rate'] = $rate[$i];
      $rows[$i]['discount'] = $discount[$i];
      $rows[$i]['item_value'] = $item_value[$i];
  }
    foreach($rows as $row) { ?>
  <tr>
    <td>
      <p style="text-align:center;">#<?php echo $row['sl_no'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $row['mat_des'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $row['hsn_code'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $row['quantity'];?></p>
    </td>
    <td>
      <p style="text-align:center;">Rs&nbsp;<?php echo $row['rate'];?></p>
    </td>
    <td>
      <p style="text-align:center;"><?php echo $row['discount'];?>%</p>
    </td>
    <td>
      <p style="text-align:center;">Rs&nbsp;<?php  echo $row['item_value'];?>/-</p>
    </td>
  </tr>

  <tr>
    <td colspan="5">
    </td>

    <td>
	<p style="text-align:center;">Total Item Value</p>
      <hr>


      <p style="text-align:center;">Taxes</p>
      <hr>

      <p style="text-align:center;">Grand Total Rs.</p>
    </td>
    <td>


      <p style="text-align:center;">Rs <?php echo $total_cost; ?>/-</p>

        <hr>

        <p style="text-align:center;">Rs <?php echo ($pay_cost-$total_cost);?>/-</p>
        <hr>

        <p style="text-align:center;">Rs&nbsp;<?php echo $pay_cost; ?>/- </p>
    </td>
  </tr>
  <?php } ?>
</table>

<p>Total GST In Word Rupees:<?php $new_igst=convert_number_to_words(($pay_cost-$total_cost));
		 echo  strtoupper($new_igst);?> ONLY</p>
<p>Total Invoice Value In Words Rupees:<?php $new_s_total=convert_number_to_words($pay_cost);
		 echo  strtoupper($new_s_total);?> ONLY </p>
     <table width="100%">
       <tr>
         <td>
             <p>1. Goods once sold will not be returned.</p>
             <p>2. All disputes are subject to Bhubaneswar Juridiction only.</p>
			 <p>Bank Name: Andra Bank, Baramunda.</p>
			 <p>Bank Account No.: 018813046000701</p>
			 <p>Branch IFSC : ANDB0000188</p>
         </td>
         <td>
          <p style="text-align:center;">for PADMALAYA</p>
           <br>
           <br>
           <p style="text-align:center;">Proprietor</p>
         </td>
       </tr>

     </table>
     <br>

     <br>
     <br>
     <br>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$( document ).ready(function() {

 // window.print();
//  window.close();
});
</script>
</html>
