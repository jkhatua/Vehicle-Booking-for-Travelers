-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2018 at 05:59 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `saisradha`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyerdetails`
--

CREATE TABLE IF NOT EXISTS `buyerdetails` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `gstin` varchar(40) NOT NULL,
  `pan` varchar(40) NOT NULL,
  `cin` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `dilevery_chalan`
--

CREATE TABLE IF NOT EXISTS `dilevery_chalan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challan_no` varchar(100) NOT NULL,
  `challan_date` varchar(40) NOT NULL,
  `offer_no` varchar(100) NOT NULL,
  `purchase_date` varchar(100) NOT NULL,
  `order_no` varchar(100) NOT NULL,
  `no_of_pkg` int(10) NOT NULL,
  `dispatched` varchar(100) NOT NULL,
  `net_wt` int(10) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `serial_no` int(10) NOT NULL,
  `mat_des` int(10) NOT NULL,
  `pl_serial_no` int(10) NOT NULL,
  `material_code` int(10) NOT NULL,
  `hsn_code` int(10) NOT NULL,
  `unit` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `duty_slip`
--

CREATE TABLE IF NOT EXISTS `duty_slip` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dutyslip_slno` varchar(20) NOT NULL,
  `duty_of` varchar(50) NOT NULL,
  `report_at` int(50) NOT NULL,
  `booked_by` int(50) NOT NULL,
  `car_no` int(20) NOT NULL,
  `driver_name` int(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `start_date` varchar(50) NOT NULL,
  `starting_km` varchar(15) NOT NULL,
  `start_time` varchar(15) NOT NULL,
  `closing_km` varchar(15) NOT NULL,
  `closing_time` varchar(15) NOT NULL,
  `closing_date` varchar(15) NOT NULL,
  `total_km` varchar(15) NOT NULL,
  `total_time` varchar(15) NOT NULL,
  `local_long_fixed` varchar(15) NOT NULL,
  `ac_nonac` varchar(15) NOT NULL,
  `toll_gate` varchar(15) NOT NULL,
  `parking_charge` varchar(15) NOT NULL,
  `day_night_holt` varchar(15) NOT NULL,
  `advance_paid_client` decimal(10,2) NOT NULL,
  `advance_paid_travel` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `insertproduct`
--

CREATE TABLE IF NOT EXISTS `insertproduct` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_details` varchar(100) NOT NULL,
  `order_no` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `so_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `place_of_supply` varchar(200) NOT NULL,
  `sl_no` int(10) NOT NULL,
  `mat_code` varchar(100) NOT NULL,
  `mat_des` varchar(100) NOT NULL,
  `hsn_code` varchar(10) NOT NULL,
  `freight` int(10) NOT NULL,
  `cgst` varchar(40) NOT NULL,
  `sgst` varchar(100) NOT NULL,
  `igst` varchar(10) NOT NULL,
  `customer_drg_no` varchar(100) NOT NULL,
  `quantity` int(10) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `discount` int(10) NOT NULL,
  `amount` float NOT NULL,
  `tax_cost` decimal(10,2) NOT NULL,
  `pay_cost` decimal(10,2) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bill` int(10) NOT NULL,
  `quantity_avail` int(10) NOT NULL,
  `volume` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pdc_buyer`
--

CREATE TABLE IF NOT EXISTS `pdc_buyer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `emp_catagory` varchar(100) NOT NULL,
  `emp_name` varchar(40) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `birth_date` varchar(255) NOT NULL,
  `joining_date` varchar(255) NOT NULL,
  `aadhar_cardno` varchar(15) NOT NULL,
  `dl_no` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `status` int(4) NOT NULL DEFAULT '1' COMMENT '1 -> True 0 -> False',
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pdc_buyer`
--

INSERT INTO `pdc_buyer` (`id`, `emp_catagory`, `emp_name`, `father_name`, `contact_no`, `emailid`, `birth_date`, `joining_date`, `aadhar_cardno`, `dl_no`, `address`, `status`, `creationDate`) VALUES
(1, 'driver', '45454544', '5444', '45454', '777', '2018-03-20', '2018-03-20', '45454', '6554454', '454545', 1, '2018-03-20 17:37:48'),
(2, 'employee', 'subrat', 'bikash', '9853113045', 'hgghg@gmail.com', '2018-03-21', '2018-03-21', '123456', '147abc', 'ctc', 1, '2018-03-21 04:54:05');

-- --------------------------------------------------------

--
-- Table structure for table `sellitems`
--

CREATE TABLE IF NOT EXISTS `sellitems` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_details` varchar(100) NOT NULL,
  `po_no` varchar(100) NOT NULL,
  `new_customer` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `offer_no` varchar(100) NOT NULL,
  `gstin` varchar(100) NOT NULL,
  `dispatched` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `invoice_date` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `challan_no` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `challan_date` varchar(40) NOT NULL,
  `serial_no` int(10) NOT NULL,
  `mat_des` int(40) NOT NULL,
  `pl_serial_no` varchar(10) NOT NULL,
  `hsn_code` int(10) NOT NULL,
  `unit` int(10) NOT NULL,
  `purchase_rate` int(10) NOT NULL,
  `tax_amount` int(10) NOT NULL,
  `total_cost` int(10) NOT NULL,
  `rate` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `item_value` int(10) NOT NULL,
  `discount` int(10) NOT NULL,
  `sgst` int(10) NOT NULL,
  `cgst` int(10) NOT NULL,
  `igst` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `pay_cost` int(10) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bill` int(10) NOT NULL,
  `income` int(10) NOT NULL,
  `mrp` varchar(100) NOT NULL,
  `retail` int(10) NOT NULL DEFAULT '0',
  `volume` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `name`) VALUES
(1, 'Andaman and Nicobar Islands union territory'),
(2, 'Andhra Pradesh'),
(3, 'Arunachal Pradesh'),
(4, 'Assam'),
(5, 'Bihar'),
(6, 'Chandigarh '),
(7, 'Chhattisgarh'),
(8, 'Dadra and Nagar Haveli '),
(9, 'Daman and Diu '),
(10, 'Delhi'),
(11, 'Goa'),
(12, 'Gujarat'),
(13, 'Haryana'),
(14, 'Himachal Pradesh'),
(15, 'Jammu and Kashmir'),
(16, 'Jharkhand'),
(17, 'Karnataka'),
(18, 'Kerala'),
(19, 'Lakshadweep '),
(20, 'Madhya Pradesh'),
(21, 'Maharashtra'),
(22, 'Manipur'),
(23, 'Meghalaya'),
(24, 'Mizoram'),
(25, 'Nagaland'),
(26, 'Odisha'),
(27, 'Puducherry'),
(28, 'Punjab'),
(29, 'Rajasthan'),
(30, 'Sikkim'),
(31, 'Tamil Nadu'),
(32, 'Telangana'),
(33, 'Tripura'),
(34, 'Uttar Pradesh'),
(35, 'Uttarakhand'),
(36, 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `stockdetails`
--

CREATE TABLE IF NOT EXISTS `stockdetails` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(100) NOT NULL,
  `mat_code` varchar(100) NOT NULL,
  `mat_des` varchar(100) NOT NULL,
  `hsn_code` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `avail` int(10) NOT NULL,
  `used` int(10) NOT NULL,
  `damaged` int(10) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transhistory`
--

CREATE TABLE IF NOT EXISTS `transhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `invoice_no` varchar(20) NOT NULL,
  `invAmount` int(10) NOT NULL,
  `amount` int(20) NOT NULL,
  `pending` int(20) NOT NULL,
  `newBal` int(10) NOT NULL,
  `date` varchar(40) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `bill` int(10) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role_name`) VALUES
(1, 'admin', 'admin', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
