<div class="fixed-sidebar-right">
	<ul class="right-sidebar">
		<li>
			<div  class="tab-struct custom-tab-1">

				<div class="tab-content" id="right_sidebar_content">
					<div  id="chat_tab" class="tab-pane fade active in" role="tabpanel">
								<div class="message-box-wrap">
									<div class="msg-search">
										<a href="javascript:void(0)" class="inline-block txt-grey">
											<i class="zmdi zmdi-more"></i>
										</a>
										<span class="inline-block txt-dark">Suppliers</span>

										<div class="clearfix"></div>
									</div>
									<div class="set-height-wrap">
										<div class="streamline message-box nicescroll-bar">
                			<a href="javascript:void(0)">
												<div class="sl-item unread-message">
													<div class="sl-avatar avatar avatar-sm avatar-circle">
														<img class="img-responsive img-circle" src="images/user.jpg" alt="avatar"/>
													</div>
													<div class="sl-content">
														<span class="inline-block capitalize-font   pull-left message-per">asdasd</span>
														<span class="inline-block font-11  pull-right message-time">GST : asdasd</span>
														<div class="clearfix"></div>
														<p class="txt-grey truncate">adadas</p>
													</div>
												</div>
											</a>
                  	</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
