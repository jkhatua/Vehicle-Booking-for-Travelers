<div class="fixed-sidebar-left">
  <ul class="nav navbar-nav side-nav nicescroll-bar">
    <li class="navigation-header">
      <span>Main</span>
      <i class="zmdi zmdi-more"></i>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "dashboard.php") echo "class='active'"; ?> href="dashboard.php"  ><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Dashboard</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "create-buyer.php") echo "class='active'"; ?> href="create-buyer.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">Add Driver / Employee</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "buyer-details.php") echo "class='active'"; ?> href="buyer-details.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">View Driver / Employee</span></div><div class="clearfix"></div></a>
    </li>
	
	 <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "create-buyer.php") echo "class='active'"; ?> href="create-buyer.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">Add Car Details</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "buyer-details.php") echo "class='active'"; ?> href="buyer-details.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">View Car Details</span></div><div class="clearfix"></div></a>
    </li>


    <li><hr class="light-grey-hr mb-10"/></li>
    <li class="navigation-header">
      <span>component</span>
      <i class="zmdi zmdi-more"></i>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "supplier-invoice-form.php") echo "class='active'"; ?> href="supplier-invoice-form.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">Add Product</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "invoice-archive.php") echo "class='active'"; ?> href="invoice-archive.php"><div class="pull-left"><i class="zmdi zmdi-shopping-basket mr-20"></i><span class="right-nav-text">Supplier Invoice Archieve</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "pending-amount.php") echo "class='active'"; ?> href="pending-amount.php"><div class="pull-left"><i class="zmdi zmdi-edit mr-20"></i><span class="right-nav-text">Pending Amount</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "transanction-history.php") echo "class='active'"; ?> href="transanction-history.php"><div class="pull-left"><i class="zmdi zmdi-edit mr-20"></i><span class="right-nav-text">Transanction History</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "stock-details.php") echo "class='active'"; ?> href="stock-details.php"><div class="pull-left"><i class="zmdi zmdi-edit mr-20"></i><span class="right-nav-text">Stock Details</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a  <?php if(basename($_SERVER['PHP_SELF']) == "create-party.php") echo "class='active'"; ?> href="create-party.php"><div class="pull-left"><i class="zmdi zmdi-smartphone-setup mr-20"></i><span class="right-nav-text">Create Customer</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "manage-party-details.php") echo "class='active'"; ?> href="manage-party-details.php"><div class="pull-left"><i class="zmdi zmdi-smartphone-setup mr-20"></i><span class="right-nav-text">Manage Customer</span></div><div class="clearfix"></div></a>
    </li>

    <li><hr class="light-grey-hr mb-10"/></li>
    <li class="navigation-header">
      <span>Inventory</span>
      <i class="zmdi zmdi-more"></i>
    </li>

    <li>
			<a <?php if(basename($_SERVER['PHP_SELF']) == "income-report-daily.php" || basename($_SERVER['PHP_SELF']) == "income-report-weekly.php" || basename($_SERVER['PHP_SELF']) == "income-report-monthly.php" || basename($_SERVER['PHP_SELF']) == "income-report.php") echo "class='active'"; ?>href="javascript:void(0);" data-toggle="collapse" data-target="#table_dr"><div class="pull-left"><i class="fa fa-inr mr-20"></i><span class="right-nav-text">Income(As per Invoice)</span></div><div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div><div class="clearfix"></div></a>
					<ul id="table_dr" class="collapse collapse-level-1 two-col-list">
						<li>
							<a <?php if(basename($_SERVER['PHP_SELF']) == "income-report-daily.php") echo "class='active-page'"; ?> href="income-report-daily.php">Today's Income</a>
						</li>
						<li>
							<a <?php if(basename($_SERVER['PHP_SELF']) == "income-report-weekly.php") echo "class='active-page'"; ?> href="income-report-weekly.php">Weekly's Income</a>
						</li>
            <li>
							<a <?php if(basename($_SERVER['PHP_SELF']) == "income-report-monthly.php") echo "class='active-page'"; ?> href="income-report-monthly.php">Monthly's Income</a>
						</li>
						<li>
							<a <?php if(basename($_SERVER['PHP_SELF']) == "income-report.php") echo "class='active-page'"; ?> href="income-report.php">Total Income</a>
						</li>
					</ul>
				</li>
        <!-- <li><hr class="light-grey-hr mb-10"/></li>
        <li class="navigation-header">
          <span>Inventory</span>
          <i class="zmdi zmdi-more"></i>
        </li> -->

    <li><hr class="light-grey-hr mb-10"/></li>
    <li class="navigation-header">
      <span>featured</span>
      <i class="zmdi zmdi-more"></i>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "tax-invoice.php") echo "class='active'"; ?> href="tax-invoice.php"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Tax Invoice</span></div><div class="clearfix"></div></a>
    </li>
	
	 <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "retail-invoice.php") echo "class='active'"; ?> href="retail-invoice.php"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Retail Invoice</span></div><div class="clearfix"></div></a>
    </li>

    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "tax-invoice-archieve.php") echo "class='active'"; ?> href="tax-invoice-archieve.php"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Tax Invoice Archieve</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a <?php if(basename($_SERVER['PHP_SELF']) == "dilevery-chalan.php") echo "class='active'"; ?> href="dilevery-chalan.php"><div class="pull-left"><i class="zmdi zmdi-filter-list mr-20"></i><span class="right-nav-text">Delivery Chalan</span></div><div class="clearfix"></div></a>
    </li>
    <li>
      <a href="logout.php"><div class="pull-left"><i class="fa fa-sign-out mr-20" ></i><span class="right-nav-text">Log Out</span></div><div class="clearfix"></div></a>
    </li>
  </ul>
</div>
