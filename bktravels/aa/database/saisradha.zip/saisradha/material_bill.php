<?php
	include('config.php');
	function fetchProduct1(){
		global $mysqli;
		$stmt = $mysqli->prepare("SELECT DISTINCT
		id,
		mat_des
		FROM insertProduct
		");
		$stmt->execute();
		$stmt->bind_result($id,$mat_des);
		while($stmt->fetch()){
			$row[] = array('id' =>$id ,'mat_des' => $mat_des );
		}
		$stmt->close();
		if(!empty($row))
		{
			return ($row);
		}
		else
		{
			return "";
		}
	}
	function fetchProductDetailsbyID($itemtypeid){
		global $mysqli;
		$stmt = $mysqli->prepare("SELECT
		id,
		hsn_code,
		quantity,
		amount,
		tax_cost,
		cgst,
		sgst,
		igst,
		rate,
		discount,
		mat_code,
		quantity_avail
		FROM insertProduct
		WHERE id = ?
		");
		$stmt->bind_param("s",$itemtypeid);
		$stmt->execute();
		$stmt->bind_result($id,$hsn_code,$quantity,$amount,$tax_cost,$cgst,$sgst,$igst,$rate,$discount,$mat_code,$quantity_avail);
		while($stmt->fetch()){
			$row[] = array('id' =>$id ,'hsn_code' => $hsn_code,'quantity'=>$quantity,'amount'=>$amount,'tax_cost'=>$tax_cost,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'rate'=>$rate,'discount'=>$discount,'mat_code'=>$mat_code,'quantity_avail'=>$quantity_avail );
		}
		$stmt->close();
		if(!empty($row))
		{
			return ($row);
		}
		else
		{
			return "";
		}
	}


	if($_POST['action'] == 'itemreplace')
	{
		$html1 = '<option value="" selected disabled>Select the  Product</option>';
		$fetchProduct = fetchProduct1();
					foreach ($fetchProduct as $v1) {
		   $html1.='<option value="'.$v1['id'].'">'.$v1['mat_des'].'</option>';
		}

		echo $html1;
	}
	if($_POST['action']=='price'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['rate'];
		}
	}
	if($_POST['action']=='tax'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['rate']*(($v1['sgst']/100) + ($v1['cgst']/100)+ ($v1['igst']/100));
		}
	}
	if($_POST['action']=='total_price'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['rate']+($v1['rate']*(($v1['sgst']/100) + ($v1['cgst']/100)+ ($v1['igst']/100)));
		}
	}
	if($_POST['action']=='hsn_code'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['hsn_code'];
		}
	}
	if($_POST['action']=='quantity'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['quantity_avail'];
		}
	}
	if($_POST['action']=='SGST'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['sgst'];
		}
	}
	if($_POST['action']=='CGST'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['cgst'];
		}
	}
	if($_POST['action']=='IGST'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['igst'];
		}
	}
	if($_POST['action']=='material_code'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['mat_code'];
		}
	}
	if($_POST['action']=='Unit'){
		$itemtypeid = $_POST['itemtypeid'];
		$result = fetchProductDetailsbyID($itemtypeid);
		foreach ($result as $v1) {
			echo $v1['quantity'];
		}
	}
	?>
