<?php
include('config.php');
    if(!isset($_SESSION))
    {
        session_start();
    }
	if(!$_SESSION)
	{
		header('location:index.php');
	}
	$sessionname = $_SESSION['login_user'];
	if($sessionname){

    $id = $_GET['id'];

    function fetchBill($id){
      global $mysqli;
      $stmt = $mysqli->prepare("SELECT
      pdc_Buyer.name,
      pdc_Buyer.contact,
      invoice_no,
      pay_cost,
      freight
      FROM insertProduct
      INNER JOIN pdc_Buyer ON insertProduct.customer_details = pdc_Buyer.id
      WHERE bill = ?
      LIMIT 1
      ");
      $stmt->bind_param("s",$id);
      $stmt->execute();
      $stmt->bind_result($name,$contact,$invoice_no,$pay_cost,$freight);
      while($stmt->fetch()){
        $row = array('name' => $name,'contact'=>$contact,'invoice_no'=>$invoice_no,'pay_cost'=>$pay_cost,'freight'=>$freight);
      }
      $stmt->close();
      if(!empty($row))
    	{
    		return ($row);
    	}
    	else
    	{
    		return "";
    	}
    }

$fetchBill4 = fetchBill($id);



?>
<!DOCTYPE html>
<html lang="en">

<?php include("include/header.php"); ?>

	<body>
		<!--Preloader-->
		<div class="preloader-it">
			<div class="la-anim-1"></div>
		</div>
		<!--/Preloader-->

		<div class="wrapper theme-4-active pimary-color-red">

			<!-- Top Menu Items -->
			<?php include("include/top_nav.php"); ?>
			<!-- /Top Menu Items -->

			<!-- Left Sidebar Menu -->
			<?php include("include/nav.php"); ?>
			<!-- /Left Sidebar Menu -->

			<!-- Right Sidebar Menu -->
			<?php include("include/dash_supplier.php"); ?>
			<!-- /Right Sidebar Menu -->

			<!-- Right Setting Menu -->
			<?php include("include/theme_color.php"); ?>
			<!-- /Right Setting Menu -->

			<!-- Right Sidebar Backdrop -->
			<div class="right-sidebar-backdrop"></div>
			<!-- /Right Sidebar Backdrop -->

			<!-- Main Content -->
			<div class="page-wrapper">
				<div class="container-fluid">

					<!-- Title -->
					<div class="row heading-bg">
						<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
							<h5 class="txt-dark">Payment</h5>
						</div>


						<!-- Breadcrumb -->
						<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
							<ol class="breadcrumb">
								<li><a href="dashboard.php">Dashboard</a></li>
								<li class="active"><span>Payment Details</span></li>
							</ol>
						</div>
						<!-- /Breadcrumb -->

					</div>
					<!-- /Title -->




					<!-- Row -->
					<div id="table_data"></div>
					<!-- /Row -->
          <div class="row">
            <div class="col-md-12">
              <div class="panel panel-default card-view">
                <div class="panel-heading">
                  <div class="pull-left">
                    <h6 class="panel-title txt-dark">	</h6>
                  </div>
                  <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                  <div class="panel-body">
                    <div class="row">


                      <div class="col-sm-12 col-xs-12">
                        <div class="form-wrap">
                          <form id="submit_payment" action="ajax_submit_payment.php" method="post" >
                            <div class="form-body">
                              <h6 class="txt-dark capitalize-font"><i class="zmdi zmdi-account mr-10"></i>Bill's Info</h6>
                              <hr class="light-grey-hr"/>
                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label class="control-label mb-10">Supplier Name</label>
                                    <input type="text" name="name" id="firstName" class="form-control" value="<?php  echo $fetchBill4['name'];?>" placeholder="Supplier's Name" style="background-color:#212121" readonly>
                                    <span class="help-block"> </span>
                                  </div>
                                </div>

                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Contact Number</label>
                                    <input type="text" data-mask="999 999 9999" maxlength="10" name="contact" value="<?php echo $fetchBill4['contact'];?>"  class="form-control"  placeholder="Mobile No" style="background-color:#212121" readonly>

                                    <span class="help-block"> </span>
                                  </div>
                                </div>
                                <input type="hidden" name="invAmount" value="<?php echo $fetchBill4['pay_cost']; ?>" >

                              </div>

                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Invoice No</label>
                                    <input type="text"  name="invoice_no" class="form-control" placeholder="Invoice No" value="<?php echo $fetchBill4['invoice_no']; ?>" style="background-color:#212121" readonly>
                                    <span class="help-block"> </span>
                                  </div>
                                </div>

                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Balance Amount</label>
                                    <input type="text"  name="amount"  class="form-control"  placeholder="Balance Amount" value="<?php  echo $fetchBill4['freight'];?>" style="background-color:#212121" readonly>
                                    <span class="help-block">  </span>
                                  </div>
                                </div>

                              </div>

                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Pending Amount</label>
                                    <input type="text" name="pending" class="form-control" placeholder="Pending Balance to be paid">
                                    <span class="help-block">  </span>
                                  </div>
                                </div>

                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Mode of Payment</label>
                                    <select type="text" class="form-control" name="mode" >
                                      <option value="" selected disabled>Select Payment Mode</option>
                                      <option value="">Cash</option>
                                      <option value="">Cheque</option>
                                      <option value="">DD</option>
                                    </select>
                                    <span class="help-block">  </span>
                                  </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Date</label>
                                    <input type="date"  name="date"  maxlength="15" class="form-control" value="<?php echo date('Y-m-d'); ?>" style="background-color:#212121" readonly>
                                    <span class="help-block"> </span>
                                  </div>
                                </div>

                                <div class="col-md-6">
                                  <div class="form-group ">
                                    <label class="control-label mb-10">Remarks</label>
                                    <input type="text"  name="remarks"  class="form-control"  placeholder="Remarks">
                                    <span class="help-block">  </span>
                                  </div>
                                </div>
                                <input type="hidden" name="bill" value="<?php echo $id; ?>" >
                              </div>
                            </div>
                            <div class="form-actions mt-10">
                              <button type="submit" class="btn btn-success  mr-10"> Save</button>
                              <button type="reset" value="Reset" class="btn btn-default">Reset</button>
                            </div>
                          </form>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

					<!-- Row -->

					<!-- /Row -->

				</div>

				<!-- Footer -->
				<?php include("include/footer.php"); ?>
				<!-- /Footer -->

			</div>
			<!-- /Main Content -->

		</div>
		<!-- /#wrapper -->

		<!-- JavaScript -->

		<!-- jQuery -->


		<script src="vendors/bower_components/jquery/dist/jquery.min.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

	<!-- Data table JavaScript -->
	<script src="vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="vendors/bower_components/jszip/dist/jszip.min.js"></script>
	<script src="vendors/bower_components/pdfmake/build/pdfmake.min.js"></script>
	<script src="vendors/bower_components/pdfmake/build/vfs_fonts.js"></script>
  <script src="vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="dist/js/export-table-data.js"></script>

	<!-- Slimscroll JavaScript -->
	<script src="dist/js/jquery.slimscroll.js"></script>

	<!-- Owl JavaScript -->
	<script src="vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

	<!-- Switchery JavaScript -->
	<script src="vendors/bower_components/switchery/dist/switchery.min.js"></script>


	<!-- Fancy Dropdown JS -->
	<script src="dist/js/dropdown-bootstrap-extended.js"></script>
  <script src="vendors/bower_components/sweetalert/dist/sweetalert.min.js"></script>

	<!-- Init JavaScript -->
	<script src="dist/js/init.js"></script>
  <script type="text/javascript">
      var frm = $('#submit_payment');
      frm.submit(function (e) {
          e.preventDefault();
          $.ajax({
              type: frm.attr('method'),
              url:  frm.attr('action'),
              data: frm.serialize(),
              success: function (data) {
                  swal("Good job!", "The Amount is Successfully Updated!! You can check the further Report in Transanction History", "success")
                  //$('#submit_seller')[0].reset();
              },
              error: function (data) {
                  alert('An error occurred.');
              },
          });
      });




  </script>
	</body>

</html>
<?php } ?>
