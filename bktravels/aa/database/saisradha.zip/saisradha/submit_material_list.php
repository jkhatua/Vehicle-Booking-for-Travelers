<?php
	include('config.php');
		$customer_details = $_POST['customer_details'];
		$new_customer = $_POST['new_customer'];
		$address = $_POST['address'];
		$gstin = $_POST['gstin'];
		$invoice_no = $_POST['invoice_no'];
		$challan_no = "0";
		$po_no = '0';
		$offer_no = "0";
		$dispatched = $_POST['dispatched'];
		$remarks = '0';
		$code = $_POST['code'];
		$invoice_date = '0';
		$challan_date = '0';
		$state = $_POST['state'];
		$date = $_POST['date'];
		$serial_no = $_POST['serial_no'];
		$mat_des = $_POST['mat_des'];
		$pl_serial_no = $_POST['pl_serial_no'];
		$hsn_code = $_POST['hsn_code'];
		$quantity = $_POST['quantity'];
		$unit = $_POST['unit'];
		$rate = $_POST['rate'];
		$tax_amount = $_POST['tax_amount'];
		$total_cost = $_POST['total_cost'];
		$purchase_rate = $_POST['purchase_rate'];
		$item_value = $_POST['item_value'];
		$discount = $_POST['discount'];
		$sgst = $_POST['sgst'];
		$cgst = $_POST['cgst'];
		$igst = $_POST['igst'];
		$amount = $_POST['amount'];
		$pay_cost = $_POST['pay_cost'];
		$income = $_POST['income'];
		$stock = $_POST['stock'];


function fetchLastBill(){
	global $mysqli;
	$stmt = $mysqli->prepare("SELECT
	bill
	FROM sellItems
	ORDER BY id DESC LIMIT 1
	");
	$stmt->execute();
	$stmt->bind_result($bill);
	$stmt->store_result();
  $stmt->fetch();
  $stmt->close();
	return $bill;
}

print_r($mat_des);
print_r($stock);

function UpdateStockUsed(&$stock,&$mat_des){
	global $mysqli;
	$stmt = $mysqli->prepare("UPDATE insertProduct SET
	quantity_avail = ?
	WHERE id = ?
	");
	$stmt->bind_param("ss",$stock,$mat_des);
	$stmt->execute();
	$stmt->close();
	return true;
}

function insertSellingItem($customer_details,$po_no,$new_customer,$date,$address,$offer_no,$gstin,$dispatched,$invoice_no,$state,$invoice_date,$code,
$challan_no,$remarks,$challan_date,&$serial_no,&$mat_des,&$pl_serial_no,&$hsn_code,&$unit,&$purchase_rate,&$tax_amount,&$total_cost,&$rate,&$quantity,
&$item_value,&$discount,&$sgst,&$cgst,&$igst,&$amount,$pay_cost,$bill,&$income){
	global $mysqli;
	$stmt = $mysqli->prepare("INSERT INTO sellItems(
		customer_details,
		po_no,
		new_customer,
		date,
		address,
		offer_no,
		gstin,
		dispatched,
		invoice_no,
		state,
		invoice_date,
		code,
		challan_no,
		remarks,
		challan_date,
		serial_no,
		mat_des,
		pl_serial_no,
		hsn_code,
		unit,
		purchase_rate,
		tax_amount,
		total_cost,
		rate,
		quantity,
		item_value,
		discount,
		sgst,
		cgst,
		igst,
		amount,
		pay_cost,
		bill,
		income
	)
	VALUES(
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?,
		?
	)");
	$stmt->bind_param("ssssssssssssssssssssssssssssssssss",$customer_details,$po_no,$new_customer,$date,$address,$offer_no,$gstin,$dispatched,$invoice_no,$state,$invoice_date,$code,$challan_no,$remarks,$challan_date,$serial_no,$mat_des,$pl_serial_no,$hsn_code,$unit,$purchase_rate,$tax_amount,$total_cost,$rate,$quantity,$item_value,$discount,$sgst,$cgst,$igst,$amount,$pay_cost,$bill,$income);
	$stmt->execute();
	$inserted_id = $mysqli->insert_id;
	$stmt->close();

	if($inserted_id>0)
	{
		return $inserted_id;
	}
	else
	{
		return false;
	}
}

$bill = fetchLastBill() + 1;


if(!empty($mat_des)){
	for($i = 0; $i<count($mat_des); $i++) {
		$sql = insertSellingItem($customer_details,$po_no,$new_customer,$date,$address,$offer_no,$gstin,
		$dispatched,$invoice_no,$state,$invoice_date,$code,$challan_no,$remarks,$challan_date,
		$serial_no[$i],$mat_des[$i],$pl_serial_no[$i],$hsn_code[$i],$unit[$i],$purchase_rate[$i],
		$tax_amount[$i],$total_cost[$i],$rate[$i],$quantity[$i],$item_value[$i],$discount[$i],$sgst[$i],
		$cgst[$i],$igst[$i],$amount[$i],$pay_cost,$bill,$income[$i]);
	}
}

if(!empty($stock)){
	for($i = 0; $i<count($stock); $i++) {
		$sql2 = UpdateStockUsed($stock[$i],$mat_des[$i]);
		print_r($sql2);
	}
}

	?>
