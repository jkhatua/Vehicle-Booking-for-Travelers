<?php  if(!empty($_GET['printid'])) {
?>
<style>
table {
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;

}
span{
  text-transform: uppercase;
}
p{
    margin-top: 2px;
    margin-bottom: 2px;
}
body{
  margin-left: 40px;
  margin-right: 40px;
}
hr{
  margin-top: 2px;
  margin-bottom: 2px;
}
@media print {
html,body{height:100%;width:100%;margin:0;padding:0;}
 @page {
  size: 21cm 29.7cm;
	max-height:100%;
	max-width:100%
  font-size: 8pt;
  overflow: hidden;
	}
}
  #printbtn{
    visibility: : none !important;
  }
</style>
<?php
include("config.php");
require_once("include/numbertowords.php");
function fetchBuyer($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  pdc_Buyer.name as customerName,
  pdc_Buyer.address as Address,
  pdc_Buyer.gstin,
  pdc_Buyer.pan,
  pdc_Buyer.cin
  FROM insertProduct
  INNER JOIN pdc_Buyer ON insertProduct.customer_details = pdc_Buyer.id
  WHERE insertProduct.bill = ?
  LIMIT 1
  ");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($customerName,$address,$gstin,$pan,$cin);
  while($stmt->fetch()){
    $row[] = array('customerName' => $customerName,'address'=>$address,'gstin'=>$gstin,'pan'=>$pan,'cin'=>$cin );
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else{
    return "";
  }
}
function fetchInvoiceNo($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  invoice_no,
  rdate,
  place_of_supply
  FROM insertProduct
  WHERE bill = ?
  LIMIT 1");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($invoice_no,$rdate,$place_of_supply);
  while($stmt->fetch()){
    $row[] = array('invoice_no' =>$invoice_no ,'rdate'=>$rdate,'place_of_supply'=>$place_of_supply );
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else {
    return "";
  }
}

function fetchBill($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  sl_no,
  mat_des,
  mat_code,
  hsn_code,
  quantity,
  rate,
  discount,
  amount,
  cgst,
  sgst,
  igst
  FROM insertProduct
  WHERE bill = ?
  ");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($sl_no,$mat_des,$mat_code,$hsn_code,$quantity,$rate,$discount,$amount,$cgst,$sgst,$igst);
  while($stmt->fetch()){
    $row[] = array('sl_no' =>$sl_no ,'mat_des' => $mat_des,'mat_code'=>$mat_code,'hsn_code'=>$hsn_code,'quantity'=>$quantity,'rate'=>$rate,'discount'=>$discount,'amount'=>$amount,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst);
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else {
    return "";
  }
}
function calculateGST($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  sl_no,
  mat_des,
  hsn_code,
  SUM(quantity),
  SUM(rate),
  discount,
  SUM(amount),
  AVG(cgst),
  AVG(sgst),
  AVG(igst),
  tax_cost,
  pay_cost,
  SUM(customer_drg_no)
  FROM insertProduct
  WHERE bill = ?
  ");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($sl_no,$mat_des,$hsn_code,$quantity,$rate,$discount,$amount,$cgst,$sgst,$igst,$tax_cost,$pay_cost,$customer_drg_no);
  while($stmt->fetch()){
    $row[] = array('sl_no' =>$sl_no,'mat_des' => $mat_des,'hsn_code'=>$hsn_code,'quantity'=>$quantity,'rate'=>$rate,'discount'=>$discount,'amount'=>$amount,'cgst'=>$cgst,'sgst'=>$sgst,'igst'=>$igst,'tax_cost'=>$tax_cost,'pay_cost'=>$pay_cost,'customer_drg_no'=>$customer_drg_no);
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else {
    return "";
  }
}
function calculateTax($id){
  global $mysqli;
  $stmt = $mysqli->prepare("SELECT
  AVG(CGST),
  AVG(SGST),
  SUM(rate),
  hsn_code,
  SUM(amount)
  FROM insertProduct
  WHERE bill = ?
  GROUP BY hsn_code
  ");
  $stmt->bind_param("s",$id);
  $stmt->execute();
  $stmt->bind_result($cgst,$sgst,$rate,$hsn_code, $amount);
  while ($stmt->fetch()) {
    $row[] = array('cgst' => $cgst ,'sgst'=>$sgst,'rate'=>$rate,'hsn_code'=>$hsn_code, 'amount' => $amount );
  }
  $stmt->close();
  if(!empty($row)){
    return $row;
  } else {
    return "";
  }
}
$id = $_GET['printid'];
$fetchInvoice =  fetchInvoiceNo($id);
$fetchBills = fetchBill($id);
$calculateGST = calculateGST($id);
$calculateTax = calculateTax($id);
$Buyer = fetchBuyer($id);  ?>
<!DOCTYPE html>
<html lang="en">
<body>
<table width="100%">
  <tr>
    <?php foreach ($Buyer as $v2) { ?>
    <td>
      <span><b><?php echo $v2['customerName']; ?></span></b><br>
      ADDRESSS:<span><?php echo $v2['address']; ?></span><br>
      GSTIN:<span><?php echo $v2['gstin']; ?></span><br>
      PAN:<span><?php echo $v2['pan']; ?></span><br>
      CIN:<span><?php echo $v2['cin']; ?></span><br>
    </td>
    <?php  } ?>

    <?php foreach ($fetchInvoice as $v1) { ?>
    <td>
      Invoice No:<br>
      <?php echo $v1['invoice_no']; ?>
      <hr>
      Dilevary Note:
      <br><br>
      <hr>
      Supplier Ref:
      <br><br>
    </td>
    <td>
      DATED<br>
      <?php echo $v1['rdate']; ?>
      <?php } ?>
      <hr>
      Mode/Terms of Payment
      <br><br>
      <hr>
      Other Refrence(s)
      <br><br>
    </td>
  </tr>
    <tr>
     <td width="70%" rowspan="2">
        <b>PADMALAYA</b></p>
		  AUTH. DEALER : FINOLEX CABLE, CG LIGHTING, ALMONARD FANS</p>
		  ANCHOR, CONA, LEGRAND, PHILIPS, BAJAJ, MARU</p>
          Shop No. 01-37/38, P.D. Market</p>
          CRP Square, BBSR-15</p>
          Ph. 0674-2560909 (O), 9437060909</p>
          GSTIN :21AATPC0841J1ZY
      </td>
      <td>
        Buyer Order No<br><br>
        <hr>
        Dispached Document No<br><br>
        <hr>
        Dispatched through<br><br>
      </td>
      <td>
        Dated<br><br>
        <hr>
        Dilevary Note Date<br><br>
        <hr>
        Destination<br><br>
      </td>
    </tr>
    <tr>
      <td colspan="2">
      Terms of Delivery<br><br><br><br><br><br></td>
    </tr>
</table>
<br>
<table width="100%">
  <tr>
    <th>Sl No</th>
    <th>Description of Goods</th>
    <th>Part No</th>
    <th>HSN/SAC Code</th>
    <th>Quantity</th>
    <th>Rate</th>
    <th>per</th>
    <th>Discount(%)</th>
    <th>Amount</th>
  </tr>
  <?php foreach ($fetchBills as $v3) { ?>
    <tr>
      <td><?php echo $v3['sl_no']; ?></td>
      <td><?php echo $v3['mat_des']; ?></td>
      <td><?php echo $v3['mat_code']; ?></td>
      <td><?php echo $v3['hsn_code']; ?></td>
      <td><?php echo $v3['quantity']; ?></td>
      <td><?php echo $v3['rate']; ?></td>
      <td>psc</td>
      <td><?php echo $v3['discount']; ?></td>
      <td>Rs&nbsp;<?php echo round($v3['amount'],2); ?>/-</td>
    </tr>
    <?php } ?>
    <tr>
      <?php foreach ($calculateGST as $v4) { ?>
      <td colspan="7"></td>
      <td><b>Total</b></td>
      <td><b>Rs&nbsp;<?php echo round($v4['amount'],2); ?>/-</b></td>
    </tr>
    <tr>
      <td colspan="8"> CGST %</td>
      <td>Rs&nbsp;<?php echo round(($v4['customer_drg_no'] / 2),2);?>/- </td>
    </tr>
    <tr>
      <td colspan="8"> SGST %</td>
      <td>Rs&nbsp;<?php echo round(($v4['customer_drg_no'] / 2),2);?> /-</td>
    </tr>
    <tr>
      <td colspan="4"><b>Total Amount to Pay</b></td>
      <td><b><?php echo $v4['quantity']; ?></b></td>
      <td colspan="3"></td>
      <td><b>Rs&nbsp;<?php echo round($v4['pay_cost'],2); ?>/-</b></td>
    </tr>
    <?php } ?>
</table>
<br>
  TOTAL AMOUNT IN WORDS : <b><span style="font-size:20"><?php echo  convert_number_to_words($v4['pay_cost']); ?> ONLY</span></b>
<br><br>
<table width="100%">
  <tr>
    <th rowspan="2">HSN/SAC Code</th>
    <th rowspan="2">Taxable Value</th>
    <th colspan="2">Central Tax</th>
    <th colspan="2">State Tax</th>
  </tr>
  <tr>
    <th>Rate(%)</th>
    <th>Amount</th>
    <th>Rate(%)</th>
    <th>Amount</th>
  </tr>
  <?php foreach ($calculateTax as $v5) { ?>
    <tr>
      <td><?php echo $v5['hsn_code']?></td>
      <td>Rs&nbsp;<?php echo round($v5['amount'],2); ?></td>
      <td><?php echo (float)$v5['cgst']; ?>%</td>
      <td>Rs&nbsp;<?php echo round(($v5['amount'] * ($v5['cgst']/100)),2); ?></td>
      <td><?php echo (float)$v5['sgst']; ?>%</td>
      <td>Rs&nbsp;<?php echo round(($v5['amount'] * ($v5['sgst']/100)),2); ?></td>
    </tr>
  <?php  } ?>
  <tr>
    <td><b>Total Tax Amount</td>
    <td><b>Rs&nbsp;<?php echo round($v4['amount'],2);?></b></td>
    <td><b>(%)</b></td>
    <td><b>Rs&nbsp;<?php echo round(($v4['customer_drg_no'] / 2),2);?></b></td>
    <td><b>(%)</b></td>
    <td><b>Rs&nbsp;<?php echo round(($v4['customer_drg_no'] / 2),2);?></b></td>
  </tr>
</table>
  <br>
    TAX AMOUNT IN WORDS : <b><span style="font-size:20"><?php echo  convert_number_to_words(round($v4['customer_drg_no'],2)); ?> ONLY</span></b>
  <br>
  <table width="100%">
    <tr>
      <td>
        Declaration <br>
        We declare that this invoice shows the
        actual price of the<br> goods described and that all the particulars are true and correct
      </td>
      <td>
        <center>for <?php echo $v2['customerName']; ?></center>
        <br>
        <br>
        <br>
        <center>Authorigatory Signature</center>
      </td>
    </tr>
  </table>
  <center><b>SUBJECT TO ODISHA JURISDICTION<br>This is a Computer Generated Invoice</b></center>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$( document ).ready(function() {
 //window.print();
 //window.close();
});
</script>
</html>

<?php } else {header('Location : dashboard.php');}  ?>
