<?php print_r($_POST);

$customer_details = $_POST['customer_details'];
$date = $_POST['start_date'];
$date = date("y-m-h",strtotime($date));
$order_no = $_POST['order_no'];
$so_no = $_POST['so_no'];
$invoice_no = $_POST['invoice_no'];
$place_of_supply = $_POST['place_of_supply'];
$serial_no = $_POST['sl_no'];
$mat_code = $_POST['mat_code'];
$mat_des = $_POST['mat_des'];
$customer_drg_no = $_POST['customer_drg_no'];
$quantity = $_POST['quantity'];
//$item_value = $_POST['item_value'];
$discount = $_POST['discount'];
$amount = $_POST['amount'];
$pay_cost = $_POST['pay_cost'];
//$pl_serial_no = $_POST['pl_serial_no'];
$freight = $_POST['freight'];
$hsn_code = $_POST['hsn_code'];
//if($order_no==0)  $order_no=0;
$rate = $_POST['rate'];
$cgst=$_POST['cgst'] ;
$sgst = $_POST['sgst'];
$igst = $_POST['igst'];
$tax_cost = $_POST['tax_cost'];
$quantity_avail = $_POST['quantity'];




foreach ($rate as $key => $value) {
    echo $key . ' contains ' . $value . '<br/>';
}


for($i=0;$i<count($serial_no);$i++) {
    $rows[$i]['mat_code'] = $mat_code[$i];
    $rows[$i]['mat_des'] = $mat_des[$i];
    $rows[$i]['amount'] = $amount[$i];
}


?>
<table>
    <tr>
        <th>Item Id</th>
        <th>Itemname</th>
        <th>Itembrand</th>
        <th>Itemmodel</th>
    </tr>
    <?php
    $i=1;
    foreach($rows as $row) {
        echo '<tr>';
        echo '<td>'.$i.'</td>';
        echo '<td>'.$row['mat_code'].'</td>';
        echo '<td>'.$row['mat_des'].'</td>';
        echo '<td>'.$row['amount'].'</td>';
        echo '</tr>';
        $i++;
    }
    ?>
</table>
