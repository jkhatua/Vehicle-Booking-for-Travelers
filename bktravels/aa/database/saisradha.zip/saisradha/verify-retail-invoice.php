<?php
include('config.php');
    if(!isset($_SESSION))
    {
        session_start();
    }
	if(!$_SESSION)
	{
		header('location:index.php');
	}

	$sessionname = $_SESSION['login_user'];
	if($sessionname){

    $customer_details = $_POST['customer_details'];
    $date = $_POST['start_date'];
    $date = date("y-m-h",strtotime($date));
    $order_no = $_POST['order_no'];
    $so_no = $_POST['so_no'];
    $invoice_no = $_POST['invoice_no'];
    $place_of_supply = $_POST['place_of_supply'];
    $serial_no = $_POST['sl_no'];
    $mat_code = $_POST['mat_code'];
    $mat_des = $_POST['mat_des'];
    $customer_drg_no = 0;
    $quantity = $_POST['quantity'];
    //$item_value = $_POST['item_value'];
    $discount = $_POST['discount'];
    $amount = $_POST['amount'];
    $pay_cost = $_POST['pay_cost'];
    //$pl_serial_no = $_POST['pl_serial_no'];
    $freight = $_POST['freight'];
    $hsn_code = $_POST['hsn_code'];
    //if($order_no==0)  $order_no=0;
    $rate = $_POST['rate'];
    $cgst=$_POST['cgst'] ;
    $sgst = $_POST['sgst'];
    $igst = $_POST['igst'];
    $tax_cost = $_POST['tax_cost'];
    $quantity_avail = $_POST['quantity'];


?>
<!DOCTYPE html>
<html lang="en">

<?php include("include/header.php"); ?>

	<body>
		<!--Preloader-->
		<div class="preloader-it">
			<div class="la-anim-1"></div>
		</div>
		<!--/Preloader-->

		<div class="wrapper theme-4-active pimary-color-red">

			<!-- Top Menu Items -->
			<?php include("include/top_nav.php"); ?>
			<!-- /Top Menu Items -->

			<!-- Left Sidebar Menu -->
			<?php include("include/nav.php"); ?>
			<!-- /Left Sidebar Menu -->

			<!-- Right Sidebar Menu -->
			<?php include("include/dash_supplier.php"); ?>
			<!-- /Right Sidebar Menu -->

			<!-- Right Setting Menu -->
			<?php include("include/theme_color.php"); ?>
			<!-- /Right Setting Menu -->

			<!-- Right Sidebar Backdrop -->
			<div class="right-sidebar-backdrop"></div>
			<!-- /Right Sidebar Backdrop -->

			<!-- Main Content -->
			<div class="page-wrapper">
				<div class="container-fluid">

					<!-- Title -->
					<div class="row heading-bg">
						<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
							<h5 class="txt-dark">Stock Details</h5>
						</div>


						<!-- Breadcrumb -->
						<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
							<ol class="breadcrumb">
								<li><a href="dashboard.php">Dashboard</a></li>
								<li class="active"><span>Stock Details</span></li>
							</ol>
						</div>
						<!-- /Breadcrumb -->

					</div>
					<!-- /Title -->

					<div id="msg"></div>

					<!-- Row -->
          <div class="row">
						<div class="col-md-12">
							<div class="panel panel-default card-view">
								<div class="panel-heading">
									<div class="pull-left">
										<h6 class="panel-title txt-dark">Read only</h6>
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="panel-wrapper collapse in">
									<div class="panel-body">
										<div class="row">
											<div class="col-md-12">
												<div class="form-wrap">
													<form class="form-horizontal" role="form">
														<div class="form-body">
															<h6 class="txt-dark capitalize-font"><i class="zmdi zmdi-account mr-10"></i>Person's Info</h6>
															<hr class="light-grey-hr"/>
															<div class="row">
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">Customer Name:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $customer_details; ?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">Order No:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $order_no;?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
															</div>
															<!-- /Row -->
															<div class="row">
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">Date:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $date;?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">S.O. No:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $so_no;?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
															</div>
															<!-- /Row -->
															<div class="row">
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">Invoice No:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $invoice_no;?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
																<div class="col-md-6">
																	<div class="form-group">
																		<label class="control-label col-md-3">Place of Supply:</label>
																		<div class="col-md-9">
																			<p class="form-control-static"> <?php echo $place_of_supply;?> </p>
																		</div>
																	</div>
																</div>
																<!--/span-->
															</div>
															<!-- /Row -->



														</div>
														<!-- <div class="form-actions mt-10">
															<div class="row">
																<div class="col-md-6">
																	<div class="row">
																		<div class="col-md-offset-3 col-md-9">
																			<button type="submit" class="btn btn-info btn-icon left-icon  mr-10"> <i class="zmdi zmdi-edit"></i> <span>Edit</span></button>
																			<button type="button" class="btn btn-default">Cancel</button>
																		</div>
																	</div>
																</div>
																<div class="col-md-6"> </div>
															</div>
														</div> -->
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /Row -->

					<!-- /Row -->

          <?php  print_r($hsn_code); ?>

					<!-- Row -->
					<div class="row" id="pks1">
						<div class="col-sm-12">
							<div class="panel panel-default card-view">
								<div class="panel-wrapper collapse in">
									<div class="panel-body">
                    <div class="pull-right">
    									<a href="#" class="pull-left inline-block full-screen mr-15">
    										<i class="zmdi zmdi-fullscreen"></i>
    									</a>
    								</div>
										<h6 class="txt-dark capitalize-font"><i class="zmdi zmdi-account mr-10"></i>Stock Details</h6>
										<hr class="light-grey-hr"/>
										<div class="table-wrap">
											<div class="table-responsive">
												<table class="table mb-0">
													<thead>
														<tr>
                              <th>ID</th>
                              <th>Company Code</th>
                              <th>Model No</th>
                              <th>HSN Code</th>
                              <th>CGST(%)</th>
                              <th>SGST(%)</th>
                              <th>IGST(%)</th>
                              <th>Customer DRG No</th>
                              <th>Quantity</th>
                              <th>Rate/Each</th>
                              <th>Discount</th>
                              <th>Amount</th>
                              <th>Total Amount</th>
														</tr>
													</thead>
													<tfoot>
														<tr>
                              <th>ID</th>
                              <th>Company Code</th>
                              <th>Model No</th>
                              <th>HSN Code</th>
                              <th>CGST(%)</th>
                              <th>SGST(%)</th>
                              <th>IGST(%)</th>
                              <th>Customer DRG No</th>
                              <th>Quantity</th>
                              <th>Rate/Each</th>
                              <th>Discount</th>
                              <th>Amount</th>
                              <th>Total Amount</th>
														</tr>
													</tfoot>
													<tbody>
                            <?php
                            for($i=0;$i<count($serial_no);$i++) {
                                $rows[$i]['sl_no'] = $serial_no[$i];
                                $rows[$i]['mat_code'] = $mat_code[$i];
                                $rows[$i]['mat_des'] = $mat_des[$i];
                                $rows[$i]['hsn_code'] = $hsn_code[$i];
                                $rows[$i]['cgst'] = $cgst[$i];
                                $rows[$i]['sgst'] = $sgst[$i];
                                $rows[$i]['igst'] = $igst[$i];
                                $rows[$i]['customer_drg_no'] = $customer_drg_no[$i];
                                $rows[$i]['quantity'] = $quantity[$i];
                                $rows[$i]['rate'] = $rate[$i];
                                $rows[$i]['discount'] = $discount[$i];
                                $rows[$i]['amount'] = $amount[$i];
                                $rows[$i]['tax_cost'] = $tax_cost[$i];
                            }
                              foreach($rows as $row) { ?>
                            <tr>
                              <td><?php echo $row['sl_no'];?></td>
                              <td><?php echo $row['mat_code'];?></td>
                              <td><?php echo $row['mat_des'];?></td>
                              <td><?php echo $row['hsn_code'];?></td>
                              <td><?php echo $row['cgst'];?></td>
                              <td><?php echo $row['sgst'];?></td>
                              <td><?php echo $row['igst'];?></td>
                              <td><?php echo $row['customer_drg_no'];?></td>
                              <td><?php echo $row['quantity'];?></td>
                              <td><?php echo $row['rate'];?></td>
                              <td><?php echo $row['discount'];?></td>
                              <td><?php echo $row['amount'];?></td>
                              <td><?php echo $row['tax_cost'];?></td>
                            </tr>
                          <?php } ?>
													</tbody>
												</table>
                        <div class="form-actions mt-10">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="row">
                                <div class="col-md-offset-1 col-md-11">
                                  <button type="submit" name="submit" onClick="pkss();" class="btn btn-info btn-icon left-icon  mr-10"> <i class="zmdi zmdi-edit"></i> <span>Submit</span></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  <button type="button" class="btn btn-default">Cancel</button>
                                </div>
                              </div>
                            </div>
                            <div class="col-md-6"> </div>
                          </div>
                        </div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /Row -->

				</div>

				<!-- Footer -->
				<?php include("include/footer.php"); ?>
				<!-- /Footer -->

			</div>
			<!-- /Main Content -->

		</div>
		<!-- /#wrapper -->

		<!-- JavaScript -->

		<!-- jQuery -->

		<script src="vendors/bower_components/jquery/dist/jquery.min.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

	<!-- Data table JavaScript -->
	<script src="vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.flash.min.js"></script>
	<script src="vendors/bower_components/jszip/dist/jszip.min.js"></script>
	<script src="vendors/bower_components/pdfmake/build/pdfmake.min.js"></script>
	<script src="vendors/bower_components/pdfmake/build/vfs_fonts.js"></script>
	<script src="vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
	<script src="vendors/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
	<script src="dist/js/export-table-data.js"></script>

	<!-- Slimscroll JavaScript -->
	<script src="dist/js/jquery.slimscroll.js"></script>

	<!-- Owl JavaScript -->
	<script src="vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

	<!-- Switchery JavaScript -->
	<script src="vendors/bower_components/switchery/dist/switchery.min.js"></script>


	<!-- Fancy Dropdown JS -->
	<script src="dist/js/dropdown-bootstrap-extended.js"></script>

	<!-- Init JavaScript -->
	<script src="dist/js/init.js"></script>
	<script>
	function pkss(){
    //alert('clicked');
    document.location.reload(true);
}


	</script>
	</body>

</html>
<?php } ?>
